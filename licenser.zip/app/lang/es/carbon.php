<?php
     return array(
        'timediff' => array(
             'second' => 'Hace :delta segundo|Hace :delta segundos',
             'minute' => 'Hace :delta minuto|Hace :delta minutos',
             'hour' => 'Hace :delta hora|Hace :delta horas',
             'day' => '{1} Ayer|{2} Antes de ayer|[3,Inf] Hace :delta días',
             'month' => 'Hace :delta mes|Hace :delta meses',
             'year' => 'Hace :delta año|Hace :delta años',
       ),
);