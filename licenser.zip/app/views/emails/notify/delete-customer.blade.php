<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
</head>
<body>
	<h2>Un cliente ha sido eliminado.</h2>

	<hr>

	<strong>Recepcionista: </strong> {{ $recepcionista }} <br>

	<strong>Sucursal: </strong> {{ $sucursal }} <br>

	<strong>Cliente: </strong> {{ $cliente }} <br>
</body>
</html>
