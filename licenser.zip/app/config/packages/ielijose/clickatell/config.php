<?php

return array(

	'user' => 'servicioswebmoviles-oficial',

	'password' => 'SaaEMeZSWgOBFQ',

	'api_id' => '3523542',

);
